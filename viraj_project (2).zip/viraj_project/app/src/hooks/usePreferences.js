import { useContext } from "react";
import Preferences from '../context/Preferences';

export default () => useContext(Preferences);
